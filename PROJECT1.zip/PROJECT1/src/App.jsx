import React from 'react';
import Home from './componenets/Home'
import About from './componenets/About'
import Contact from './componenets/Contact';
import Navbar from './componenets/navbar';
import { Routes,Route } from 'react-router-dom';
import './index.css';
import Counter from './componenets/Counter';
import Hooks from './componenets/Hooks';
import State from './assets/Hooks/State';


const App = () => {

   return (
    <div>
     
  <Navbar/>
    <Routes>
    <Route path='/about' element={<About/>}></Route>
    <Route path='/contact' element={<Contact/>}></Route>
    <Route path='/Home' element={<Home/>}></Route>
      <Route path='/counter' element={<Counter/>}></Route>
      <Route path='/hooks' element={<Hooks/>}> </Route>
      <Route path='/state' element={<State/>}></Route>
    </Routes>
  </div>
   )
}
export default App;