import React from 'react'
import {Link} from 'react-router-dom'

const Hooks = () => {
  return (
    <div>
        <Link to="/state">useState</Link>
    </div>
  )
}

export default Hooks