import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

function Navbar() {
  return (
    <navbar>
      <Link to="/home" className="Link">Home</Link>
      <Link to="/about" className="Link">About</Link>
      <Link to="/contact" className="Link">Contact</Link>
      <Link to="/counter" className="Link">Counter</Link>
       <Link to="/hooks" className="Link">Hooks</Link>

    </navbar>
  );
}

export default Navbar;
