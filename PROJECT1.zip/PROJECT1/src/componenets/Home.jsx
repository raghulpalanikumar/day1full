import React from 'react';

const Home = ({ items, users }) => {
  return (
    <div>
      <h1>Hello</h1>
    </div>
  );
};

export default Home;
