import { Component } from "react";

class Skill extends Component {
  render() {
    return (
      <div>
        <h1>Skills</h1>
      </div>
    );
  }
}
export default Skill;